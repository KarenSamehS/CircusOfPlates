package Controller;

public interface State {

        public void handle();
}
