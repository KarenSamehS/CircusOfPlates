package Controller;

public interface Strategy  {
    public int getTimeout();
    public int getSpeed();
}

