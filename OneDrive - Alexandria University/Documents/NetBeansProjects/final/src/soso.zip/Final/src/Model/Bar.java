/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;



/**
 *
 * @author Arwa Mohamed
 */
public class Bar extends ImageObject  {
    public Bar(int x, int y, String path) {
        super(x, y, path);

    }
    @Override
    public void setY(int y) {
    }

    @Override
    public void setX(int x) {
    }




}
