package Controller;

public class GameOverState implements State {
    @Override
    public void handle() {
        
    }
}
